
    <footer class="mt-5 pt-3 pb-2">
        <div class="container text-center"><p class="m-0 text-center text-white">© Copyright 2022 - <a href="">Insta Pro Downloader</a> - All rights reserved</p>
            <p class="text-white"><a href="#"> Terms of Use</a> | <a href="#">Privacy Policy</a> | <a href="#">Contact Us</a></p>
        </div>
    </footer>
	
<?php
echo $advancede_f_code;
ob_end_flush();
?>