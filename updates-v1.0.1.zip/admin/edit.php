<?php
ob_start();
include '../config/title.php';
if(isset($_POST['home']) && isset($_POST['tagline']) && isset($_POST['description']) && isset($_POST['photo_video']) && isset($_POST['reels']) && isset($_POST['igtv']) /*add_isset*/ ){
$home = str_replace('"',"'",$_POST['home']);
$tagline = str_replace('"',"'",$_POST['tagline']);
$description = str_replace('"',"'",$_POST['description']);
$photo_video = str_replace('"',"'",$_POST['photo_video']);
$reels = str_replace('"',"'",$_POST['reels']);
$igtv = str_replace('"',"'",$_POST['igtv']);
//add_variables

$file = '../config/title.php';
$old = ['title_home="'.$title_home.'";', 'title_tagline="'.$title_tagline.'";', 'title_description="'.$title_description.'";', 'title_photo_video="'.$title_photo_video.'";', 'title_reels="'.$title_reels.'";', 'title_igtv="'.$title_igtv.'";' /*add_old*/ ];
$new   = ['title_home="'.$home.'";', 'title_tagline="'.$tagline.'";', 'title_description="'.$description.'";', 'title_photo_video="'.$photo_video.'";', 'title_reels="'.$reels.'";', 'title_igtv="'.$igtv.'";' /*add_new*/ ];
$contents = file_get_contents($file);
$contents = str_replace($old, $new, $contents);
file_put_contents($file, $contents);
header("location:?action=updated");
exit;
}
ob_end_flush();
?>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>Update Website Details - Insta Pro Downloader</title>
	<?php include "includes/header.php"; ?>
                    <h2 class="title">Update Website Details</h2>
                    <form method="POST">
                                <div class="input-group">
                                    <label class="label">Home Page Title</label>
                                    <input class="input--style-4" type="text" name="home" value="<?php echo $title_home; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Tagline</label>
                                    <input class="input--style-4" type="text" name="tagline" value="<?php echo $title_tagline; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Website Description</label>
                                    <input class="input--style-4" type="text" name="description" value="<?php echo $title_description; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Photos Videos Downloader Title</label>
                                    <input class="input--style-4" type="text" name="photo_video" value="<?php echo $title_photo_video; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Reels Downloader Title</label>
                                    <input class="input--style-4" type="text" name="reels" value="<?php echo $title_reels; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">IGTV Downloader Title</label>
                                    <input class="input--style-4" type="text" name="igtv" value="<?php echo $title_igtv; ?>">
                                </div>
								<!-- Add Title Editor Here -->
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php
	if($_GET['action'] == "updated"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Successfully updated!!",
          icon: "success",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
	include "includes/footer.php"; ?>