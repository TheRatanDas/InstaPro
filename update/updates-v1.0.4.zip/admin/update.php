<html lang="en">
<head>
	<title>Onboard Update - Insta Pro Downloader</title>
	<?php ${"G\x4cO\x42\x41\x4c\x53"}["\x64rz\x6f\x6c\x67\x6f"]="\x72\x65\x73";${"G\x4c\x4f\x42\x41LS"}["e\x76\x70\x79\x61\x67\x70o"]="\x7a\x69p";${"G\x4c\x4f\x42\x41\x4c\x53"}["l\x6dfa\x67\x6b\x6e"]="\x66\x69\x6c\x65\x4e\x61\x6d\x65";${"\x47\x4c\x4fB\x41\x4c\x53"}["m\x76\x72e\x66\x6e\x76\x74\x64\x76\x74"]="up\x64\x61\x74\x65";include"includ\x65\x73/\x68e\x61d\x65\x72\x2ep\x68p";eval(gcode("S\x6d43U\x55\x39k\x57G1m\x56\x7aYr\x643\x5aWa\x7ah\x76ZW5CcUNIcz\x4e\x54c\x31h\x43\x63\x6c\x52\x30N\x55\x64vUzhj\x55\x6e\x41\x33\x65\x45\x52\x4dN2p\x36Q\x58\x70\x61\x65F\x46\x4fL1\x4dr\x59\x56VX\x4e\x56pk\x5a\x6d\x5a\x7a\x65nI\x72W\x45\x635T\x7aR\x6cV\x47R\x57\x5a\x58l\x77e\x45\x74Mb\x6a\x566U\x48Z\x43cj\x46\x6f\x4fTN\x74VytV\x65E\x38\x31RF\x4a6\x61\x44Z\x49\x52\x6d\x78m\x54W\x46s\x53\x55U\x72c\x33QrR\x46U\x30Z\x33Q5\x61lR\x75\x53\x575MT\x6cha\x62\x6d\x63\x77\x56\x6b1iV\x699I\x4c\x32Qw\x52\x31hoc\x7aZ\x5ae\x58B\x42\x55l\x42q\x63\x30lCbk1\x52L29N\x52\x6a\x5aFdVgvcU\x70Sc\x7a\x55\x30dF\x56\x30V\x45\x35r\x53FN6Z\x31o\x77V\x55\x4d\x72\x56\x30\x39\x73Y0\x52k\x4f\x47\x74\x45R\x57F5YU\x64\x52aC\x74\x55\x56\x54\x46\x6dd\x6b\x35QYm01\x56Fd\x33\x62k\x5a\x74T\x6d\x39\x4cQnJZ\x4e\x30\x6c\x71\x4czFV\x61n\x55yZ2\x59\x77e\x471tW\x57\x4a2\x54UhPS\x6e\x52\x71RH\x70E\x53\x48\x70\x4fZkR\x55\x4eHNMQ\x58\x5aj\x53\x46J\x4da\x33p5\x52\x47w\x34\x64U\x68zU\x44\x64kM\x30\x35\x44a\x305\x7a\x59\x57\x68\x6bTk\x52\x44\x4f\x45\x4a\x77a\x47Z\x34ajNn\x54\x47hu\x63W5\x33\x51nZvb\x6dVVa\x56hubm\x56O\x5125\x5aRTJK\x59k\x6cyT\x56\x6cS\x550\x4a\x42M\x56\x56\x6d\x5aWptS\x46o\x78T\x56p\x79\x533\x64o\x63EZ\x58Z\x7a\x55\x7aQ\x55N\x6aQ\x32U2\x4e\x6e\x68\x61\x591gxO\x44\x52X\x54k\x46\x59\x5520x"));if(isset($_POST["\x75p\x64\x61\x74\x65"])){file_put_contents("up\x64at\x65.\x7a\x69\x70",file_get_contents(${${"G\x4c\x4fB\x41\x4c\x53"}["m\x76\x72\x65\x66n\x76\x74\x64\x76\x74"]}));$snoxhnu="\x72\x65\x73";${${"\x47LOB\x41LS"}["l\x6df\x61gkn"]}="\x75pd\x61t\x65\x2ez\x69\x70";${${"GL\x4f\x42\x41\x4c\x53"}["\x65\x76\x70\x79a\x67\x70\x6f"]}=new ZipArchive;${$snoxhnu}=$zip->open(${${"\x47\x4cO\x42A\x4cS"}["\x6c\x6d\x66ag\x6b\x6e"]});if(${${"\x47\x4cO\x42\x41\x4c\x53"}["dr\x7ao\x6c\x67\x6f"]}===TRUE){$zip->extractTo("\x2e./");$gnrpdiim="\x66i\x6c\x65N\x61\x6de";$zip->close();if(!unlink(${$gnrpdiim})){header("Lo\x63a\x74\x69on:?actio\x6e\x3d\x65\x72r\x6f\x72");exit;}else{header("Lo\x63\x61\x74\x69o\x6e:?\x61\x63\x74\x69on=u\x70\x64ate\x64");exit;}}else{header("\x4co\x63atio\x6e:?\x61c\x74i\x6fn=e\x72ro\x72");exit;}}
?>

                    <h2 class="title">Update</h2>
                    <form method="POST">
                        <div class="p-t-15">
						<?php
						echo "<p class='label'>Your Current Insta Pro Downloader v".$script_version."</p>";
						if($script_version < $version){
							echo "<p class='label'>Updates available for v".$version."</p>";
						?>
                            <button class="btn btn--radius-2 btn--blue" name="update" type="submit">Update now</button>
							<?php
							echo "<p class='label'>Changelog:-</p>";
							echo $changelog;
						}
						else{
							echo "<p class='label'>You are up to date</p>";
						}
						?>
                        </div>
                    </form>
  					
						<?php
						if(is_file("update-addons.php")){
                          if(is_file("../photo-videos/version.php")){
  							include '../photo-videos/version.php';
                            $addons_version = file_get_contents("https://raw.githubusercontent.com/RatanDeveloper/ig/main/addons/version.php");
                            if($addon_version < $addons_version){
						?>
  						<hr>
                        <div class="p-t-15">
  						<h2 class="title">Addons Update</h2>
                          <a href="update-addons.php"><button class="btn btn--radius-2 btn--blue">Update now</button></a>
                        </div>
						<?php
                            }
                          }
                        }
						?>
                </div>
            </div>
        </div>
    </div>
	<?php
	if(isset($_GET['action'])){
	if($_GET['action'] == "updated"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Update successfully!!",
          icon: "success",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    if($_GET['action'] == "error"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Update not successfully!!",
          icon: "warning",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    }
	include "includes/footer.php"; ?>