<?php
error_reporting(E_ERROR | E_PARSE);
include '../config/cookie.php';
include '../config/cookiestatus.php';
  $url = "https://www.instagram.com/instagram/"."?";
  $final_url = substr($url, 0, strpos($url, "?"))."?__a=1&__d=dis";
  $opts = array(
    'http'=>array(
      'method'=>"GET",
      'header'=>"Cookie: $cookie\r\n"
    )
  );

  $context = stream_context_create($opts);

  // Open the file using the HTTP headers set above
  $jsonobj = file_get_contents($final_url, false, $context);
  
$arr = json_decode($jsonobj, true);
  
if($arr["graphql"]["user"]["username"] == true){
$current_cookie_status = "true";
}
else{
$current_cookie_status = "false";
}
if($cookie_status != $current_cookie_status){
$file = '../config/cookiestatus.php';
$old = ["cookie_status='$cookie_status';"];
$new = ["cookie_status='$current_cookie_status';"];
$contents = file_get_contents($file);
$contents = str_replace($old, $new, $contents);
file_put_contents($file, $contents);

if($current_cookie_status == "false"){
$domain = $_SERVER['SERVER_NAME'];
ini_set("sendmail_from", "insta-pro-downloader@$domain");
$to = $email;
$subject = "Your Instagram cookies have expired";
$message = "Your website's Instagram cookies have expired.Please change cookies, otherwise website users may encounter problems while using Instagram downloader.";
$header = "From:insta-pro-downloader@$domain \r\n";
mail($to,$subject,$message,$header);
}
}
?>