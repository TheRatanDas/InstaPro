<?php
include "../base.php";
session_start();
$script_version = "1.0.3";
if(!isset($_SESSION['UserData']['Username'])){
header("location:login.php");
exit;
}
?>

    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Admin Dashboard by Ratan Das">
    <meta name="author" content="Ratan Das">
    <meta name="keywords" content="Admin Dashboard by Ratan Das">

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
	<link rel="stylesheet" href="admin/style.css">
	<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
	<meta name="robots" content="noindex,nofollow" />
</head>

<body>
<nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="admin/Web_Developer.png" alt="">
                </span>

                <div class="text logo-text">
				  <a href="https://www.instagram.com/theratandas/" target="_blank" class="ratandas">
                    <span class="name">Ratan Das</span>
                    <span class="profession">Web developer</span>
				  </a>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">
			
                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="dashboard.php">
                            <i class='bx bxs-dashboard icon' ></i>
                            <span class="text nav-text">Dashboard</span>
                        </a>
                    </li>

                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="edit.php">
                            <i class='bx bx-edit icon' ></i>
                            <span class="text nav-text">Update Details</span>
                        </a>
                    </li>
                  
                    <li class="nav-link">
                        <a href="logo.php">
                            <i class='bx bxl-instagram icon' ></i>
                            <span class="text nav-text">Logo & Favicon</span>
                        </a>
                    </li>
                  
                    <li class="nav-link">
                        <a href="advanced.php">
                            <i class='bx bx-code-alt icon' ></i>
                            <span class="text nav-text">Advanced Code</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="edit-cookie.php">
                            <i class='bx bx-cookie icon' ></i>
                            <span class="text nav-text">Update Cookie</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="ads.php">
                            <i class='bx bx-code-alt icon'></i>
                            <span class="text nav-text">Ads Code</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="addon.php">
                            <i class='bx bx-add-to-queue icon' ></i>
                            <span class="text nav-text">Add Addon</span>
                        </a>
                    </li>

                </ul>
            </div>

            <div class="bottom-content">
                <li class="">
                    <a href="logout.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>
				<li class="">
                    <a href="update.php">
                        <i class='bx bxs-download icon' ></i>
                        <span class="text nav-text">Update</span>
                    </a>
                </li>

                <li class="mode">
                    <div class="sun-moon">
                        <i class='bx bx-moon icon moon'></i>
                        <i class='bx bx-sun icon sun'></i>
                    </div>
                    <span class="mode-text text">Dark mode</span>

                    <div class="toggle-switch">
                        <span class="switch"></span>
                    </div>
                </li>
                
            </div>
        </div>

    </nav>
<section class="home">
<div class="page-wrapper p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w680">
            <div class="card card-4 ml-15-mr-5">
                <div class="card-body">