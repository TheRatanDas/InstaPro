<?php
ob_start();
include '../config/title.php';
if(isset($_POST['header'])){
$header_code = str_replace('"',"'",$_POST['header']);

$file = '../config/title.php';
$old = ['advancede_code="'.$advancede_code.'";'];
$new = ['advancede_code="'.$header_code.'";'];
$contents = file_get_contents($file);
$contents = str_replace($old, $new, $contents);
file_put_contents($file, $contents);
header("location:?action=updated");
exit;
}

if(isset($_POST['footer'])){
$footer_code = str_replace('"',"'",$_POST['footer']);

$file = '../config/title.php';
$old = ['advancede_f_code="'.$advancede_f_code.'";'];
$new = ['advancede_f_code="'.$footer_code.'";'];
$contents = file_get_contents($file);
$contents = str_replace($old, $new, $contents);
file_put_contents($file, $contents);
header("location:?action=updated");
exit;
}
ob_end_flush();
?>
<html lang="en">

<head>
	<title>Update Header & Footer Code - Insta Pro Downloader</title>
  	<style>
    .advn-text {
        text-transform: none !important;
        font-size: 12px !important;
    } 
      form {
        margin-top: 40px;
    }
      .btn {
      padding: 0 20px !important;
      }
  	</style>
	<?php include "includes/header.php"; ?>
                    <h2 class="title">Update Header & Footer Code Code</h2>
                    <form method="POST">
                                <div class="input-group">
                                    <label class="label">Header Code</label>
                                    <textarea class="input--style-4" rows="5" name="header"><?php echo $advancede_code ?></textarea>
                                  	<p class="label advn-text">Add custom scripts inside <em>HEAD</em> tag. You need to have <em>SCRIPT</em> or <em>STYLE</em> tag around scripts.</p>
                                </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Update Header</button>
                        </div>
                    </form>
                    <form method="POST">
                                <div class="input-group">
                                    <label class="label">Footer Code</label>
                                    <textarea class="input--style-4" rows="5" name="footer"><?php echo $advancede_f_code ?></textarea>
                                  	<p class="label advn-text">Add custom scripts you might want to be loaded in the footer of your website. You need to have <em>SCRIPT</em> or <em>STYLE</em> tag around scripts.</p>
                                </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Update Footer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php
  	if(isset($_GET['action'])){
	if($_GET['action'] == "updated"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Successfully updated!!",
          icon: "success",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    }
	include "includes/footer.php"; ?>