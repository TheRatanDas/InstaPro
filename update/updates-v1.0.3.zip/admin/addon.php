<?php
ob_start();
if(isset($_FILES["file"]["tmp_name"])){

$temp = explode(".", $_FILES["file"]["name"])[1];
if($temp == "zip"){
    move_uploaded_file($_FILES["file"]["tmp_name"],"unzipme.zip") or die("Couldn't upload. Check permissions and retry.");
}

$fileName = "unzipme.zip";

    $zip = new ZipArchive;
    $res = $zip->open($fileName);
    if ($res === TRUE) {
      $zip->extractTo('./');
      $zip->close();
	  
	  
	if (!unlink($fileName)) {
        header('Location:?action=error');
		exit;
	}
	else {
		header('Location: ./install-addon.php');
		exit;
	}
	
    } else {
        header('Location:?action=error');
		exit;
    }

}
ob_end_flush();
?>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>Add Addon - Insta Pro Downloader</title>
<?php include "includes/header.php"; ?>
                    <h2 class="title">Add Addon</h2>
                    <form method="POST" enctype='multipart/form-data'>
                                <div class="input-group">
                                    <label class="label">Upload Addon</label>
                                    <input type='file' class="input--style-4" name='file'>
                                </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Add</button>
                        </div>
                    </form>
                        <div class="p-t-15">
                            <a href="https://store.ratandas.com/product-category/php-scripts/insta-pro-addon/" target="_blank" class="btn btn--radius-2 btn--blue">Buy Addons</a>
                        </div>
                </div>
            </div>
        </div>
    </div>
	<?php
	if(isset($_GET['action'])){
	if($_GET['action'] == "added"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Addon successfully added!!",
          icon: "success",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    if($_GET['action'] == "error"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Addon not added!!",
          icon: "warning",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    }
	include "includes/footer.php"; ?>