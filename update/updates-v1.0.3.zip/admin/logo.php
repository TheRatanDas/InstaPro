<?php
ob_start();
include '../config/title.php';
if(isset($_FILES["logo"]["tmp_name"])){

$temp = explode(".", $_FILES["logo"]["name"])[1];
if($temp == "png"){
    move_uploaded_file($_FILES["logo"]["tmp_name"],"../img/logo.png") or die("Couldn't upload. Check permissions and retry.");
  	$file = '../config/title.php';
  	$new_v = $logo_v+1;
    $old = ['logo_v="'.$logo_v.'";'];
    $new = ['logo_v="'.$new_v.'";'];
    $contents = file_get_contents($file);
    $contents = str_replace($old, $new, $contents);
    file_put_contents($file, $contents);
  	header('Location:?action=logo-uploaded');
	exit;
}else {
        header('Location:?action=logo-error');
		exit;
    }
}



if(isset($_FILES["favicon"]["tmp_name"])){

$temp = explode(".", $_FILES["favicon"]["name"])[1];
if($temp == "ico"){
    move_uploaded_file($_FILES["favicon"]["tmp_name"],"../img/favicon.ico") or die("Couldn't upload. Check permissions and retry.");
  	$file = '../config/title.php';
  	$new_v = $logo_v+1;
    $old = ['logo_v="'.$logo_v.'";'];
    $new = ['logo_v="'.$new_v.'";'];
    $contents = file_get_contents($file);
    $contents = str_replace($old, $new, $contents);
    file_put_contents($file, $contents);
  	header('Location:?action=favicon-uploaded');
	exit;
}else {
        header('Location:?action=favicon-error');
		exit;
    }
}
ob_end_flush();
?>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>Change Logo & Favicon - Insta Pro Downloader</title>
  	<style>
    .logo-text {
        text-transform: none !important;
        font-size: 12px !important;
    } 
      form {
        margin-top: 20px;
    }
      .btn {
      padding: 0 20px !important;
      }
  	</style>
<?php include "includes/header.php"; ?>
                    <h2 class="title">Change Logo & Favicon</h2>
  					<p class="label">Current Logo</p>
  					<img src="../img/logo.png?v=<?php echo $logo_v; ?>" width="150px">
  					<p class="label">Current Favicon</p>
  					<img src="../img/favicon.ico?v=<?php echo $logo_v; ?>" width="30px">
                    <form method="POST" enctype='multipart/form-data'>
                                <div class="input-group">
                                    <label class="label">Upload Logo</label>
                                    <input type='file' class="input--style-4" name='logo'>
                      				<p class="label logo-text"><em>Logo must be .png format</em></p>
                                </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Upload Logo</button>
                        </div>
                    </form>
                    <form method="POST" enctype='multipart/form-data'>
                                <div class="input-group">
                                    <label class="label">Upload Favicon</label>
                                    <input type='file' class="input--style-4" name='favicon'>
                      				<p class="label logo-text"><em>Favicon must be .ico format</em></p>
                                </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Upload Favicon</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php
	if(isset($_GET['action'])){
	if($_GET['action'] == "logo-uploaded"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Logo successfully changed!!",
          icon: "success",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    if($_GET['action'] == "logo-error"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Logo not changed!!",
          icon: "warning",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
	if($_GET['action'] == "favicon-uploaded"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Favicon successfully changed!!",
          icon: "success",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    if($_GET['action'] == "favicon-error"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Favicon not changed!!",
          icon: "warning",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    }
	include "includes/footer.php"; ?>