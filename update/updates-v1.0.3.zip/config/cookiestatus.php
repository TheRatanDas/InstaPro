<?php
$cookie_alert='';
$cookie_status='';
$email='';
?>