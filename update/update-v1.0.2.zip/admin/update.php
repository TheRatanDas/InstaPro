<html lang="en">
<head>
	<title>Onboard Update - Insta Pro Downloader</title>
	<?php include "includes/header.php";
	eval(gcode("Sm43UU9kWG1mVzYrd3ZWazhvZW5CcUNIczNTc1hCclR0NUdvUzhjUnA3eERMN2p6QXpaeFFOL1MrYVVXNVpkZmZzenIrWEc5TzRlVGRWZXlweEtMbjV6UHZCcjFoOTNtVytVeE81RFJ6aDZIRmxmTWFsSUUrc3QrRFU0Z3Q5alRuSW5MTlhabmcwVk1iVi9IL2QwR1hoczZZeXBBUlBqc0lCbk1RL29NRjZFdVgvcUpSczU0dFV0VE5rSFN6Z1owVUMrV09sY0RkOGtERWF5YUdRaCtUVTFmdk5QYm01VFd3bkZtTm9LQnJZN0lqLzFVanUyZ2YweG1tWWJ2TUhPSnRqRHpESHpOZkRUNHNMQXZjSFJMa3p5RGw4dUhzUDdkM05Da05zYWhkTkRDOEJwaGZ4ajNnTGhucW53QnZvbmVVaVhubmVOQ25ZRTJKYklyTVlSU0JBMVVmZWptSFoxTVpyS3docEZXZzUzQUNjQ2U2NnhaY1gxODRXTkFYU20x"));
	if(isset($_POST['update'])){

	file_put_contents('update.zip', file_get_contents($update));

	$fileName = "update.zip";

		$zip = new ZipArchive;
		$res = $zip->open($fileName);
		if ($res === TRUE) {
		  $zip->extractTo('../');
		  $zip->close();
		  
		  
		if (!unlink($fileName)) {
			header('Location:?action=error');
			exit;
		}
		else {
			header('Location:?action=updated');
			exit;
		}
		
		} else {
			header('Location:?action=error');
			exit;
		}


	}

	?>

                    <h2 class="title">Update</h2>
                    <form method="POST">
                        <div class="p-t-15">
						<?php
						echo "<p class='label'>Your Current Insta Pro Downloader v".$script_version."</p>";
						if($script_version < $version){
							echo "<p class='label'>Updates available for v".$version."</p>";
						?>
                            <button class="btn btn--radius-2 btn--blue" name="update" type="submit">Update now</button>
							<?php
							echo "<p class='label'>Changelog:-</p>";
							echo $changelog;
						}
						else{
							echo "<p class='label'>You are up to date</p>";
						}
						?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php
	if(isset($_GET['action'])){
	if($_GET['action'] == "updated"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Update successfully!!",
          icon: "success",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    if($_GET['action'] == "error"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Update not successfully!!",
          icon: "warning",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    }
	include "includes/footer.php"; ?>