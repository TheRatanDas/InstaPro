<?php
$adcode="";
$adblocker="";
?>