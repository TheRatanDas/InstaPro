<?php
ob_start();
include '../config/ads.php';
if(isset($_POST['adscode'])){
$adscode = str_replace('"',"'",$_POST['adscode']);
$adblockers = $_POST['adblocker'];

$file = '../config/ads.php';
$old = ['adcode="'.$adcode.'";', 'adblocker="'.$adblocker.'";'];
$new = ['adcode="'.$adscode.'";', 'adblocker="'.$adblockers.'";'];
$contents = file_get_contents($file);
$contents = str_replace($old, $new, $contents);
file_put_contents($file, $contents);
header("location:?action=updated");
exit;
}
ob_end_flush();
?>
<html lang="en">

<head>
	<title>Update Ads Code - Insta Pro Downloader</title>
  
  	<style>
    .switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 34px
    }

    .switch input {
        opacity: 0;
        width: 0;
        height: 0
    }

    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        -webkit-transition: .4s;
        transition: .4s
    }

    .slider:before {
        position: absolute;
        content: "";
        height: 26px;
        width: 26px;
        left: 4px;
        bottom: 4px;
        background-color: #fff;
        -webkit-transition: .4s;
        transition: .4s
    }

    input:checked+.slider {
        background-color: #4272d7
    }

    input:focus+.slider {
        box-shadow: 0 0 1px #4272d7
    }

    input:checked+.slider:before {
        -webkit-transform: translateX(26px);
        -ms-transform: translateX(26px);
        transform: translateX(26px)
    }

    .slider.round {
        border-radius: 34px
    }

    .slider.round:before {
        border-radius: 50%
    }
    </style>
  
	<?php include "includes/header.php"; ?>
                    <h2 class="title">Update Ads Code</h2>
                    <form method="POST">
                                <div class="input-group">
                                    <label class="label">Ads Code</label>
                                    <textarea class="input--style-4" rows="5" name="adscode"><?php echo $adcode ?></textarea>
                                </div>
                      			<?php
  								if($adblocker == "true"){
  								?>
                                <div class="input-group">
                                  <label class="label">Anti-Adblocker (<em>enabled</em>)</label>
                                    <label class="switch">
                                    <input type="checkbox" name="adblocker" value="true" checked>
                                    <span class="slider round"></span>
                                  </label>
                                </div>
                      			<?php
                                }
                                 else{
                                ?>
                                <div class="input-group">
                                    <label class="label">Anti-Adblocker (<em>disabled</em>)</label>
                                    <label class="switch">
                                    <input type="checkbox" name="adblocker" value="true">
                                    <span class="slider round"></span>
                                  </label>
                                </div>
                      			<?php
                                 }
                                ?>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php
  	if(isset($_GET['action'])){
	if($_GET['action'] == "updated"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Successfully updated!!",
          icon: "success",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    }
	include "includes/footer.php"; ?>