<div class="body-blur">
<nav class="navbar navbar-expand-md navbar-light nav-bg sticky-top shadow">
        <div class="container"><a class="navbar-brand" href=""><img src="img/logo.png?v=<?php echo $logo_v; ?>" alt="instagram downloader logo" width="65%" /></a><button class="navbar-toggler shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav text-end mt-1">
                    <li class="nav-item"><a class="nav-link" href="reels"><img src="img/icon/reels.svg" alt="Icon" width="20" height="20"> Reels</a></li>
                    <li class="nav-item"><a class="nav-link" href="igtv"><img src="img/icon/igtv.svg" alt="Icon" width="20" height="20"> IGTV</a></li>
                    <li class="nav-item"><a class="nav-link" href="#howto"><img src="img/icon/how.svg" alt="Icon" width="20" height="20"> How To</a></li>
                    <li class="nav-item"><a class="nav-link" href="#faqs"><img src="img/icon/faqs.svg" alt="Icon" width="20" height="20"> faqs</a></li>
                </ul>
            </div>
        </div>
    </nav>