<div class="row justify-content-center">
<?php
error_reporting(E_ERROR | E_PARSE);
include 'base.php';
include 'config/cookie.php';
session_start();
$token = md5(rand(1000,9999));
$_SESSION['dl_token_id'] = $token;
if(isset($_POST['url'])){
  $url = $_POST['url']."?";
  $final_url = substr($url, 0, strpos($url, "?"))."?__a=1";
  $opts = array(
    'http'=>array(
      'method'=>"GET",
      'header'=>"Cookie: $cookie\r\n"
    )
  );

  $context = stream_context_create($opts);

  // Open the file using the HTTP headers set above
  $jsonobj = file_get_contents($final_url, false, $context);
}

  $get_token = base64url_decode(strrev($_POST['token']));
  if($get_token == true && $get_token == $_SESSION['get_token']){
  
$arr = json_decode($jsonobj, true);

  $username = $arr["items"][0]["user"]["username"];
  $profile_pic_url = $arr["items"][0]["user"]["profile_pic_url"];
  
if($arr["items"][0]["video_versions"][0]["url"] == true || $arr["items"][0]["carousel_media"][0]["video_versions"][0]["url"] == true || $arr["items"][0]["carousel_media"][0]["image_versions2"]["candidates"][0]["url"] == true || $arr["items"][0]["image_versions2"]["candidates"][0]["url"] == true){

  if($arr["items"][0]["video_versions"] == true){
    $type = ".mp4";
    $url = $arr["items"][0]["video_versions"][0]["url"];
    $json = '{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$url.'"}';
    $base = strrev(base64url_encode($json));
    $dl_url = "dl.php?token=".$base;
    ?>

  			<div class="col-md-4 mt-4">
            <div class="card">
              <div class="card-header text-start">
                <div class="d-inline"><img class="w-12 rounded-circle" src="<?php echo "dl.php?token=".strrev(base64url_encode('{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$profile_pic_url.'"}')) ?>">
                <div class="ml-3 d-inline"><span class="mx-1"><?php echo $username ?></span></div>
                </div>
              </div>
              <div class="card-body text-center">
                <div class="ig-dl-container">
                <video controls>
                  <source src="<?php echo $dl_url ?>" type="video/mp4">
                </video>
                </div>
                <a href="<?php echo $dl_url ?>" class="btn btn-primary mt-3 w-90">Download Video</a>
              </div>
            </div>
			</div>

        <?php
  }
  else{
    $carousel_media_count = $arr["items"][0]["carousel_media_count"];
    $count = $carousel_media_count - 1;
      if($carousel_media_count > 0){
        for ($x = 0; $x <= $count; $x++) {
          if($arr["items"][0]["carousel_media"][$x]["video_versions"] == true){
            $type = ".mp4";
            $url = $arr["items"][0]["carousel_media"][$x]["video_versions"][0]["url"];
            $json = '{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$url.'"}';
            $base = strrev(base64url_encode($json));
            $dl_url = "dl.php?token=".$base;
    		?>

  			<div class="col-md-4 mt-4">
            <div class="card">
              <div class="card-header text-start">
                <div class="d-inline"><img class="w-12 rounded-circle" src="<?php echo "dl.php?token=".strrev(base64url_encode('{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$profile_pic_url.'"}')) ?>">
                <div class="ml-3 d-inline"><span class="mx-1"><?php echo $username ?></span></div>
                </div>
              </div>
              <div class="card-body text-center">
                <div class="ig-dl-container">
                <video controls>
                  <source src="<?php echo $dl_url ?>" type="video/mp4">
                </video>
                </div>
                <a href="<?php echo $dl_url ?>" class="btn btn-primary mt-3 w-90">Download Video</a>
              </div>
  			</div>
			</div>

        <?php
          }
          else{
            $type = ".jpg";
            $url = $arr["items"][0]["carousel_media"][$x]["image_versions2"]["candidates"][0]["url"];
            $json = '{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$url.'"}';
            $base = strrev(base64url_encode($json));
            $dl_url = "dl.php?token=".$base;
    		?>

  			<div class="col-md-4 mt-4">
			<div class="card">
              <div class="card-header text-start">
                <div class="d-inline"><img class="w-12 rounded-circle" src="<?php echo "dl.php?token=".strrev(base64url_encode('{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$profile_pic_url.'"}')) ?>">
                <div class="ml-3 d-inline"><span class="mx-1"><?php echo $username ?></span></div>
                </div>
              </div>
              <div class="card-body text-center">
                <img class="ig-dl-img" src="<?php echo $dl_url ?>">
                <a href="<?php echo $dl_url ?>" class="btn btn-primary mt-3 w-90">Download Photo</a>
              </div>
            </div>
  			</div>

			<?php
          }
        }
      }
      else{
        $type = ".jpg";
        $url = $arr["items"][0]["image_versions2"]["candidates"][0]["url"];
        $json = '{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$url.'"}';
        $base = strrev(base64url_encode($json));
        $dl_url = "dl.php?token=".$base;
        ?>

  		<div class="col-md-4 mt-4">
		<div class="card">
          <div class="card-header text-start">
            <div class="d-inline"><img class="w-12 rounded-circle" src="<?php echo "dl.php?token=".strrev(base64url_encode('{"token":"'.$token.'","username":"'.$username.'","type":"'.$type.'","url":"'.$profile_pic_url.'"}')) ?>">
            <div class="ml-3 d-inline"><span class="mx-1"><?php echo $username ?></span></div>
            </div>
          </div>
          <div class="card-body text-center">
            <img class="ig-dl-img" src="<?php echo $dl_url ?>">
            <a href="<?php echo $dl_url ?>" class="btn btn-primary mt-3 w-90">Download Photo</a>
          </div>
        </div>
  		</div>

        <?php
      }
    }
    }
  else{
  echo '<div class="alert text-center alert-danger w-auto mtb-5" role="alert"><strong>Ooops, please enter a valid Instagram link!!</strong></div>';
  }
  }
  else {
  echo "invalid token!";
  }
?>
	</div>