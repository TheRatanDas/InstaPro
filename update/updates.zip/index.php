<?php
include 'base.php';
include 'config/title.php';
include 'config/ads.php';
session_start();
$token = md5(rand(1000,9999));
$_SESSION['get_token'] = $token;
$page_title = $title_home;
?>
<html lang="en">
<head>
    <meta charset="UTF-8" />
  	<?php include 'includes/head.php'; ?>
</head>

<body>
    <?php include 'includes/navbar.php'; ?>
    <div class="container-flueid main_section py-2">
        <div class="container text-center mt-5">
            <h1 class="heading"><?php echo $title_home ?></h1>
            <h2 class="heading2"><?php echo $title_tagline ?></h2>
        </div>
        <div class="container text-center mt-4">
		<form onsubmit="event.preventDefault(); getig();">
		<input class="url_inp" type="text" id="ig_input_url" placeholder="Enter instagram photo, video, reels or igtv link ..." /><span><button class="inp_btn" type="submit"><svg class="bi bi-cloud-arrow-down" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewbox="0 0 16 16">
                        <path fill-rule="evenodd" d="M7.646 10.854a.5.5 0 0 0 .708 0l2-2a.5.5 0 0 0-.708-.708L8.5 9.293V5.5a.5.5 0 0 0-1 0v3.793L6.354 8.146a.5.5 0 1 0-.708.708l2 2z"></path>
                        <path d="M4.406 3.342A5.53 5.53 0 0 1 8 2c2.69 0 4.923 2 5.166 4.579C14.758 6.804 16 8.137 16 9.773 16 11.569 14.502 13 12.687 13H3.781C1.708 13 0 11.366 0 9.318c0-1.763 1.266-3.223 2.942-3.593.143-.863.698-1.723 1.464-2.383zm.653.757c-.757.653-1.153 1.44-1.153 2.056v.448l-.445.049C2.064 6.805 1 7.952 1 9.318 1 10.785 2.23 12 3.781 12h8.906C13.98 12 15 10.988 15 9.773c0-1.216-1.02-2.228-2.313-2.228h-.5v-.5C12.188 4.825 10.328 3 8 3a4.53 4.53 0 0 0-2.941 1.1z"></path>
                    </svg> Download</button></span>
            <div class="details p-2 text-center"></div>
            <div class="photos_videos"><div id='output'></div>
              <div class="loader-div">
              <div id="ig-loader" class="">
                  <span></span>
                  <span></span>
                  <span></span>
                  <span></span>
              </div>
              </div></div>
			</form>
			<div class="my-2">
			<?php echo $adcode; ?>
			</div>
        </div>
    </div>
    <div class="container-flueid pt-5">
	<?php include 'includes/downloaders.php'; ?>
        <div class="container-flueid mt-5 bg-white mb-3" id="howto">
            <div class="container mt-5 text-center py-3">
                <h4 class="text-primary">How to download from instagram ?</h4>
                <p class="text-success">It is very easy process to download instagram photos, videos, reels, igtv and profile pictures. Just follow our instructions.</p>
            </div>
            <div class="container mt-3 mb-4 pb-3">
                <div class="card mx-auto mt-1 shadow p-2" style="max-width:698px"><img class="card-img-top" src="img/1.webp" alt="copy instagram photo or video link" title="copy instagram photo or video link" width="100%" height="100%">
                    <div class="card-body">
                        <ul>
                            <li class="lead">Open Instagram app or website from your mobile or computer and choose the post/ photo/ video/ igtv/ reels.</li>
                            <li class="lead">Copy the Instagram post link.</li>
                            <li class="lead">You can copy the link from url bar or just click on 3 dots and click 'copy link'. </li>
                            <li class="lead">In mobile, you need to click on 3 dots and copy the link.</li>
                        </ul>
                    </div>
                </div>
                <div class="card mx-auto mt-3 shadow p-2" style="max-width:698px"><img class="card-img-top" src="img/2.webp" alt="paste instagram video download link" title="paste instagram video download link" width="100%" height="100%">
                    <div class="card-body">
                        <ul>
                            <li class="lead">Now come back to Insta Pro Downloader.</li>
                            <li class="lead">Paste the Instagram post link in URL input bar and click on 'Download' button.</li>
                        </ul>
                    </div>
                </div>
                <div class="card mx-auto mt-3 shadow p-2" style="max-width:698px"><img class="card-img-top" src="img/3.webp" alt="download instagram video or photo" title="download instagram video or photo" width="100%" height="100%">
                    <div class="card-body">
                        <ul>
                            <li class="lead">Your post is ready to download</li>
                            <li class="lead">Just select the download option and download your Instagram post.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
      <?php include 'includes/faqs.php'; ?>
    </div>
  	<?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    function getig(){
        url = $('#ig_input_url').val();
      	token = '<?php echo strrev(base64url_encode($token)) ?>';
        $.ajax({
            method:'POST',
            data:{
              'url':url,
              'token':token
            },
            url:'download.php',
            success:function(msg){
                $('#output').html(msg);
            }
        });
    }
      $(document).on({
        ajaxStart: function(){
            $("#ig-loader").addClass("loader-spinner");
          	$('#output').hide();
        },
        ajaxStop: function(){ 
            $("#ig-loader").removeClass("loader-spinner");
          	$('#output').show();
        }    
    });
    </script>
</body>

</html>