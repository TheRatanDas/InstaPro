<?php
$logo_v="0";
$advancede_code="";
$advancede_f_code="";
$title_home="Instagram Photos, Videos, Reels & IGTV Downloader";
$title_tagline="Online Instagram Downloader";
$title_description="Instagram Downloader. Download Instagram Videos, Photos, Reels, Igtv, Hashtag, Profile latest posts, private photo videos using this web-based tool for absolutely free of cost.";

$title_photo_video="Instagram Photos, Videos Downloader";
$title_reels="Instagram Reels Downloader";
$title_igtv="Instagram IGTV Downloader";
//add_title_here
?>