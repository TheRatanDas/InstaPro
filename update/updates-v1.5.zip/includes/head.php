<?php
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on'){
$CurPageURL = "https://";
}else{
$CurPageURL = "http://";
}
$CurPageURL.= $_SERVER['HTTP_HOST'];
$CurPageURL.= $_SERVER['REQUEST_URI'];
?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="<?php echo $title_description; ?>" />
    <meta name="keywords" content="Instagram Downloader,instagram video downloader, instagram photo downloader, instagram reels downloader, instagram igtv downloader, ins video dwonloader, download instagram videos, ig download, ig downloader, instagram download, istagram download video, instagram download video, instagram profile download, Insta Pro Downloader, ingram download, insta video download, instagram video download, downloader" />
    <meta name="theme-color" content="#F8F7F7" />
    <meta property="og:site_name" content="<?php echo $page_title; ?> | Instagram Downloader" />
    <meta property="og:url" content="<?php echo $CurPageURL; ?>" />
    <meta property="og:image" content="img/logo.png?v=<?php echo $logo_v; ?>" />
    <meta property="og:title" content="<?php echo $page_title; ?> | Instagram Downloader" />
    <meta property="og:description" content="<?php echo $title_description; ?>" />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:url" content="<?php echo $CurPageURL; ?>" />
    <meta name="twitter:image" content="img/logo.png?v=<?php echo $logo_v; ?>" />
    <meta name="twitter:title" content="<?php echo $page_title; ?> | Instagram Downloader" />
    <meta name="twitter:description" content="<?php echo $title_description; ?>" />
    <meta name="mobile-web-app-capable" content="yes" />
    <title><?php echo $page_title ?> | Instagram Downloader</title>
    <link rel="apple-touch-icon" href="img/favicon.ico?v=<?php echo $logo_v; ?>" />
    <link rel="canonical" href="<?php echo $CurPageURL; ?>" />
    <link rel="icon" href="img/favicon.ico?v=<?php echo $logo_v; ?>" type="image/x-icon" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

<?php
if($adblocker == "true"){
?>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js" onerror="chkAdBlock()"></script>
<script>
function chkAdBlock() {
    var blurcsslink = document.createElement('link');
    blurcsslink.rel = 'stylesheet';
    blurcsslink.type = 'text/css';
    blurcsslink.href = 'css/blur.css';
    document.getElementsByTagName('HEAD')[0].appendChild(blurcsslink);

    var swalcsslink = document.createElement('link');
    swalcsslink.rel = 'stylesheet';
    swalcsslink.type = 'text/css';
    swalcsslink.href = 'https://cdn.jsdelivr.net/gh/RatanDeveloper/sweetalert/sweetalert.css';
    document.getElementsByTagName('HEAD')[0].appendChild(swalcsslink);




    var scriptjs = document.createElement('script');
    scriptjs.src = "https://cdn.jsdelivr.net/gh/RatanDeveloper/sweetalert/sweetalert.js";
    document.getElementsByTagName('head')[0].appendChild(scriptjs);




    document.getElementsByTagName("body")[0].onload = function() {
        myloadFunctions()
    };

    function myloadFunctions() {
        swal({
                title: "You're blocking ads",
                text: "Our website is made possible by displaying online ads to our visitors. Please consider supporting us by disabling your ad blocker.",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "I have disabled Adblock",
                cancelButtonText: "Not now",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function(isConfirm) {
                if (isConfirm) {
                    location = self.location;
                } else {
                    swal("Opps!", "Please disable ad blocker then reload this page.", "error");
                }
            });
    }
}
</script>
<?php
}
echo $advancede_code;
?>