<?php
if(file_exists("start.php") == true){
header('Location: start.php');
exit;
}
include "../base.php";
include '../config/config.php';
include '../config/user.php';

session_start();
if(isset($_SESSION['UserData']['Username'])){
header("location:dashboard.php");
exit;
}

if(isset($_POST['Submit'])){
  if($recovery_email == strtolower($_POST['email'])){
    $n=16;
    function getName($n) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';

        for ($i = 0; $i < $n; $i++) {
            $index = rand(0, strlen($characters) - 1);
            $randomString .= $characters[$index];
        }

        return $randomString;
    }
    $password = getName($n);
    $file2 = '../config/user.php';
    $old2 = ['pass="'.$pass.'";'];
    $new2 = ['pass="'.$password.'";'];
    $contents2 = file_get_contents($file2);
    $contents2 = str_replace($old2, $new2, $contents2);
    file_put_contents($file2, $contents2);
    
    $domain = $_SERVER['SERVER_NAME'];
    ini_set("sendmail_from", "insta-pro-downloader@$domain");
    $to = $recovery_email;
    $subject = "Your website password has been changed";
    $message = "You may have forgotten your website password so reset it, if you haven't then check your website security\nUsername: $user\nPassword: $password";
    $header = "From:insta-pro-downloader@$domain \r\n";
    mail($to,$subject,$message,$header);
    
    $msg="<span style='color:green'>New password has been sent to your recovery email</span>";
    
  } else {
  	$msg="<span style='color:red'>Invalid Recovery Email</span>";
  }
}

?>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Admin Dashboard by Ratan Das">
    <meta name="author" content="Ratan Das">
    <meta name="keywords" content="Admin Dashboard by Ratan Das">

    <!-- Title Page-->
    <title>Forgot Password - Insta Pro Downloader</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w680">
            <div class="card card-4">
                <div class="card-body">
                    <h2 class="title">Forgot Password</h2>
                  
                          <?php if($user_login == "true"){?>
                    <form method="POST">
								<?php if(isset($msg)){ echo $msg; } ?>
                                <div class="input-group">
                                    <label class="label">Recovery Email</label>
                                    <input class="input--style-4" type="email" name="email">
                                </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" name="Submit" type="submit">Reset Password</button>
                        </div>
                    </form>
                          <?php }else{ ?>
                  					<p class="label">Password Login not enabled</p>
  									<a href="login.php"><button class="btn btn--radius-2 btn--blue">Login</button></a>
									<?php } ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>
<?php
ob_end_flush();
?>
</body><!-- This templates was made by Ratan Das (https://ratandas.com) -->

</html>
<!-- end document-->