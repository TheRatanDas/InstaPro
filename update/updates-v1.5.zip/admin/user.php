<?php
ob_start();
include '../config/config.php';
include '../config/user.php';
if(isset($_POST['purchasecode'])){
$purchasecode = str_replace('"',"'",$_POST['purchasecode']);
$activationcode = str_replace('"',"'",$_POST['activationcode']);
$username = str_replace('"',"'",$_POST['username']);
$password = str_replace('"',"'",$_POST['password']);
$status = $_POST['passlogin'];
$recoveryemail = strtolower($_POST['recoveryemail']);

$file = '../config/config.php';
$old = ['purchase_code="'.$purchase_code.'";', 'activation_key="'.$activation_key.'";'];
$new = ['purchase_code="'.$purchasecode.'";', 'activation_key="'.$activationcode.'";'];
$contents = file_get_contents($file);
$contents = str_replace($old, $new, $contents);
file_put_contents($file, $contents);

$file2 = '../config/user.php';
$old2 = ['user_login="'.$user_login.'";', 'user="'.$user.'";', 'pass="'.$pass.'";', 'recovery_email="'.$recovery_email.'";'];
$new2 = ['user_login="'.$status.'";', 'user="'.$username.'";', 'pass="'.$password.'";', 'recovery_email="'.$recoveryemail.'";'];
$contents2 = file_get_contents($file2);
$contents2 = str_replace($old2, $new2, $contents2);
file_put_contents($file2, $contents2);

header("location:?action=updated");
exit;
}
ob_end_flush();
?>
<html lang="en">

<head>
	<title>Update License and Set Password - Insta Pro Downloader</title>
  
  	<style>
    .switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 34px
    }

    .switch input {
        opacity: 0;
        width: 0;
        height: 0
    }

    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        -webkit-transition: .4s;
        transition: .4s
    }

    .slider:before {
        position: absolute;
        content: "";
        height: 26px;
        width: 26px;
        left: 4px;
        bottom: 4px;
        background-color: #fff;
        -webkit-transition: .4s;
        transition: .4s
    }

    input:checked+.slider {
        background-color: #4272d7
    }

    input:focus+.slider {
        box-shadow: 0 0 1px #4272d7
    }

    input:checked+.slider:before {
        -webkit-transform: translateX(26px);
        -ms-transform: translateX(26px);
        transform: translateX(26px)
    }

    .slider.round {
        border-radius: 34px
    }

    .slider.round:before {
        border-radius: 50%
    }
    .notif-text {
        text-transform: none !important;
        font-size: 12px !important;
    }
    </style>
  
	<?php include "includes/header.php"; ?>
                    <h2 class="title">Update License</h2>
                    <form method="POST">
                                <div class="input-group">
                                    <label class="label">Purchase Code</label>
                                    <input class="input--style-4" type="text" name="purchasecode" value="<?php echo $purchase_code; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Activation Code</label>
                                    <input class="input--style-4" type="text" name="activationcode" value="<?php echo $activation_key; ?>">
                                </div>
                      			<?php
  								if($user_login == "true"){
  								?>
                                <div class="input-group">
                                  <label class="label">Password Login (<em>enabled</em>)</label>
                                    <label class="switch">
                                    <input type="checkbox" name="passlogin" value="true" checked id="myCheck" onclick="passform()">
                                    <span class="slider round"></span>
                                  </label>
                                </div>
                      			<?php
                                }
                                 else{
                                ?>
                                <div class="input-group">
                                    <label class="label">Password Login (<em>disabled</em>)</label>
                                    <label class="switch">
                                    <input type="checkbox" name="passlogin" value="true" id="myCheck" onclick="passform()">
                                    <span class="slider round"></span>
                                  </label>
                                </div>
                      			<?php
                                 }
                                ?>
                      			<div id="setpass" style="display:none">
                    			<h2 class="title">Set Password</h2>
                                <div class="input-group">
                                    <label class="label">Username</label>
                                    <input class="input--style-4" type="text" name="username" value="<?php echo $user; ?>" id="user">
                                </div>
                                <div class="input-group">
                                    <label class="label">Password</label>
                                    <input class="input--style-4" type="text" name="password" id="pass">
                                </div>
                                <div class="input-group">
                                    <label class="label">Recovery Email</label>
                                    <input class="input--style-4" type="email" name="recoveryemail" value="<?php echo $recovery_email; ?>" id="email">
                                </div>
                      			<p class="label notif-text"><em>If your server supports PHP mail() Function then this Recovery Email feature will work on your website.</em></p>
                      			</div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<script>
if (document.getElementById("myCheck").checked == true){
  setpass.style.display = "block";
  document.getElementById("user").required = true;
  document.getElementById("pass").required = true;
  document.getElementById("email").required = true;
}
function passform() {
  var checkBox = document.getElementById("myCheck");
  var setpass = document.getElementById("setpass");
  if (checkBox.checked == true){
    setpass.style.display = "block";
    document.getElementById("user").required = true;
    document.getElementById("pass").required = true;
    document.getElementById("email").required = true;
  } else {
     setpass.style.display = "none";
    document.getElementById("user").required = false;
    document.getElementById("pass").required = false;
    document.getElementById("email").required = false;
  }
}
</script>
	<?php
  	if(isset($_GET['action'])){
	if($_GET['action'] == "updated"){
	    ?>
	    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        document.getElementsByTagName("body")[0].onload = function() {successFunctions()};
        function successFunctions() {
        swal({
          title: "Successfully updated!!",
          icon: "success",
          button: "Ok",
        });
        }
        </script>
        <?php
	}
    }
	include "includes/footer.php"; ?>