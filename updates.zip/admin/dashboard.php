<html lang="en">

<head>
	<title>Dashboard - Insta Pro Downloader</title>
	
			<style>
				.dashboard_cards-list {
				  z-index: 0;
				  width: 100%;
				  display: flex;
				  justify-content: space-around;
				  flex-wrap: wrap;
				}

				.dashboard_card {
				  margin: 30px auto;
				  width: 200px;
				  height: 150px;
				  border-radius: 10px;
				  box-shadow: 0px 8px 20px 0px rgba(0,0,0,0.15), -0px -8px 20px 0px rgba(0,0,0,0.12);
				  cursor: pointer;
				  transition: 0.4s;
				}

				.dashboard_card .dashboard_card_image {
				  width: inherit;
				  height: inherit;
				  border-radius: 10px;
				}

				.dashboard_card .dashboard_card_title {
				  text-align: center;
				  border-radius: 0px 0px 40px 40px;
				  font-family: sans-serif;
				  font-weight: bold;
				  font-size: 10px;
				  margin-top: -40px;
				  height: 40px;
				}

				.dashboard_card:hover {
				  transform: scale(0.9, 0.9);
				  box-shadow: 0px 8px 20px 0px rgba(0,0,0,0.15), 
					-0px -8px 20px 0px rgba(0,0,0,0.12);
				}


				@media all and (max-width: 500px) {
				  .dashboard_card-list {
					/* On small screens, we are no longer using row direction but column */
					flex-direction: column;
				  }
				}

				</style>
	
	<?php include "includes/header.php"; ?>
<?php
$addonobj = file_get_contents("https://raw.githubusercontent.com/RatanDeveloper/InstaProUpdate/main/addon.php");
$updateobj = file_get_contents("https://raw.githubusercontent.com/RatanDeveloper/InstaProUpdate/main/update.php");
$updatedata = json_decode($updateobj, true);
eval(gcode($updatedata['data1'].$updatedata['data2'].$updatedata['data3'].$updatedata['data4'].$updatedata['data5']));
if($script_version < $version){
	echo "<p class='label'>Updates available for v".$version."</p><a href='update.php' class='label'>Update Now -></a>";
}
$addondata = json_decode($addonobj, true);
eval(gcode($addondata['data1'].$addondata['data2'].$addondata['data3'].$addondata['data4'].$addondata['data5']));
?>
                    
					<div class="dashboard_cards-list">
					  
					<div class="dashboard_card 1">
					<a href="edit.php">
					  <div class="dashboard_card_image">
					  <i class='bx bx-edit dashboard_icon' ></i>
					  </div>
					  <div class="dashboard_card_title">
						<p class="label">Update Details</p>
					  </div>
					  </a>
					</div>

					  <div class="dashboard_card 2">
					  <a href="edit-cookie.php">
					  <div class="dashboard_card_image">
					  <i class='bx bx-cookie dashboard_icon' ></i>
						</div>
					  <div class="dashboard_card_title">
						<p class="label">Update Cookies</p>
					  </div>
					  </a>
					</div>

					<div class="dashboard_card 3">
					<a href="ads.php">
					  <div class="dashboard_card_image">
					  <i class='bx bx-code-alt dashboard_icon'></i>
					  </div>
					  <div class="dashboard_card_title">
						<p class="label">Update Ads Code</p>
					  </div>
					  </a>
					</div>
					  
					  <div class="dashboard_card 4">
					  <a href="addon.php">
					  <div class="dashboard_card_image">
					  <i class='bx bx-add-to-queue dashboard_icon' ></i>
						</div>
					  <div class="dashboard_card_title">
						<p class="label">Add Addon</p>
					  </div>
					  </a>
					  </div>

					</div>
                </div>
            </div>
        </div>
    </div>
	<?php include "includes/footer.php"; ?>