<?php
include '../config/cookie.php';
if(isset($_POST['cookies'])){
$cookies = $_POST['cookies'];

$file = '../config/cookie.php';
$old = ["cookie='$cookie';"];
$new = ["cookie='$cookies';"];
$contents = file_get_contents($file);
$contents = str_replace($old, $new, $contents);
file_put_contents($file, $contents);
}

?>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>Update Cookies - Insta Pro Downloader</title>
<?php include "includes/header.php"; ?>
                    <h2 class="title">Update Cookies</h2>
                    <form method="POST">
                                <div class="input-group">
                                    <label class="label">Cookies</label>
                                    <textarea class="input--style-4" rows="5" name="cookies"><?php echo $cookie ?></textarea>
                                </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php include "includes/footer.php"; ?>