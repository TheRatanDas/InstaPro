<?php
include '../config/title.php';
if(isset($_POST['home']) && isset($_POST['tagline']) && isset($_POST['description']) && isset($_POST['photo_video']) && isset($_POST['reels']) && isset($_POST['igtv']) && isset($_POST['hashtag']) && isset($_POST['profile']) && isset($_POST['private']) && isset($_POST['stories']) && isset($_POST['highlights'])){
$home = str_replace('"',"'",$_POST['home']);
$tagline = str_replace('"',"'",$_POST['tagline']);
$description = str_replace('"',"'",$_POST['description']);
$photo_video = str_replace('"',"'",$_POST['photo_video']);
$reels = str_replace('"',"'",$_POST['reels']);
$igtv = str_replace('"',"'",$_POST['igtv']);
$hashtag = str_replace('"',"'",$_POST['hashtag']);
$profile = str_replace('"',"'",$_POST['profile']);
$private = str_replace('"',"'",$_POST['private']);
$stories = str_replace('"',"'",$_POST['stories']);
$highlights = str_replace('"',"'",$_POST['highlights']);

$file = '../config/title.php';
$old = ['title_home="'.$title_home.'";', 'title_tagline="'.$title_tagline.'";', 'title_description="'.$title_description.'";', 'title_photo_video="'.$title_photo_video.'";', 'title_reels="'.$title_reels.'";', 'title_igtv="'.$title_igtv.'";', 'title_hashtag="'.$title_hashtag.'";', 'title_profile="'.$title_profile.'";', 'title_private="'.$title_private.'";', 'title_stories="'.$title_stories.'";', 'title_highlights="'.$title_highlights.'";'];
$new   = ['title_home="'.$home.'";', 'title_tagline="'.$tagline.'";', 'title_description="'.$description.'";', 'title_photo_video="'.$photo_video.'";', 'title_reels="'.$reels.'";', 'title_igtv="'.$igtv.'";', 'title_hashtag="'.$hashtag.'";', 'title_profile="'.$profile.'";', 'title_private="'.$private.'";', 'title_stories="'.$stories.'";', 'title_highlights="'.$highlights.'";'];
$contents = file_get_contents($file);
$contents = str_replace($old, $new, $contents);
file_put_contents($file, $contents);
}

?>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>Update Website Details - Insta Pro Downloader</title>
	<?php include "includes/header.php"; ?>
                    <h2 class="title">Update Website Details</h2>
                    <form method="POST">
                                <div class="input-group">
                                    <label class="label">Home Page Title</label>
                                    <input class="input--style-4" type="text" name="home" value="<?php echo $title_home; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Tagline</label>
                                    <input class="input--style-4" type="text" name="tagline" value="<?php echo $title_tagline; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Website Description</label>
                                    <input class="input--style-4" type="text" name="description" value="<?php echo $title_description; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Photos Videos Downloader Title</label>
                                    <input class="input--style-4" type="text" name="photo_video" value="<?php echo $title_photo_video; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Reels Downloader Title</label>
                                    <input class="input--style-4" type="text" name="reels" value="<?php echo $title_reels; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">IGTV Downloader Title</label>
                                    <input class="input--style-4" type="text" name="igtv" value="<?php echo $title_igtv; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Hashtag Downloader Title</label>
                                    <input class="input--style-4" type="text" name="hashtag" value="<?php echo $title_hashtag; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Profile Downloader Title</label>
                                    <input class="input--style-4" type="text" name="profile" value="<?php echo $title_profile; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Private Downloader Title</label>
                                    <input class="input--style-4" type="text" name="private" value="<?php echo $title_private; ?>">
                                </div>
                                <div class="input-group">
                                    <label class="label">Stories Downloader Title</label>
                                    <input class="input--style-4" type="text" name="stories" value="<?php echo $title_stories; ?>">
                                </div>
								<div class="input-group">
                                    <label class="label">Highlights Downloader Title</label>
                                    <input class="input--style-4" type="text" name="highlights" value="<?php echo $title_highlights; ?>">
                                </div>
								<!-- Add Title Editor Here -->
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php include "includes/footer.php"; ?>