<?php
include '../config/ads.php';
if(isset($_POST['adscode'])){
$adscode = str_replace('"',"'",$_POST['adscode']);

$file = '../config/ads.php';
$old = ['adcode="'.$adcode.'";'];
$new = ['adcode="'.$adscode.'";'];
$contents = file_get_contents($file);
$contents = str_replace($old, $new, $contents);
file_put_contents($file, $contents);
}

?>
<html lang="en">

<head>
	<title>Update Ads Code - Insta Pro Downloader</title>
	<?php include "includes/header.php"; ?>
                    <h2 class="title">Update Ads Code</h2>
                    <form method="POST">
                                <div class="input-group">
                                    <label class="label">Ads Code</label>
                                    <textarea class="input--style-4" rows="5" name="adscode"><?php echo $adcode ?></textarea>
                                </div>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php include "includes/footer.php"; ?>