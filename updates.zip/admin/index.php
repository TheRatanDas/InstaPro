<?php session_start();
if(isset($_SESSION['UserData']['Username'])){
header("location:dashboard.php");
exit;
}
else{
header("location:login.php");
exit;
}
?>