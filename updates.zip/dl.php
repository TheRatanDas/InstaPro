<?php
error_reporting(E_ERROR | E_PARSE);
include 'base.php';
session_start();

if(isset($_GET['token'])){
$base = $_GET['token'];
$json = base64url_decode(strrev($base));

$arr = json_decode($json, true);

$token = $arr["token"];
$url = $arr["url"];
$type = $arr["type"];
$username = $arr["username"];

if($token == true && $token == $_SESSION['dl_token_id']){
  $file_name = $username."-".rand().$type;
  header("Content-type: application/x-file-to-save"); 
  header("Content-Disposition: attachment; filename=".$file_name);
  ob_end_clean();
  readfile($url);
}
  else{
  echo "invalid token!";
  }

}
else{
    echo "error!";
}
?>