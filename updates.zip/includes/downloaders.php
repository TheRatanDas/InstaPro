      
      <div class="container">
      <hr class="mb-4 text-primary" id="tools">
      <div class="row justify-content-center mt-2 mb-5 otherLinks">
          <div class="col-md-4 col-6">
              <div class="card m-2 text-center">
                  <a href="photo-videos"><div class="card-body m-1"> <img src="img/icon/photos.svg" alt="Icon" width="20" height="20"><span> Instagram Photo Video Downloader</span></div></a>
              </div>
          </div>
          <div class="col-md-4 col-6">
              <div class="card m-2 text-center">
                  <a href="reels"><div class="card-body m-1"> <img src="img/icon/reels.svg" alt="Icon" width="20" height="20"><span> Instagram Reels Downloader</span></div></a>
              </div>
          </div>
          <div class="col-md-4 col-6">
              <div class="card m-2 text-center">
                  <a href="igtv"><div class="card-body m-1"> <img src="img/icon/igtv.svg" alt="Icon" width="20" height="20"><span> Instagram IGTV Downloader</span></div></a>
              </div>
          </div>
          <div class="col-md-4 col-6">
              <div class="card m-2 text-center">
                  <a href="hashtag"><div class="card-body m-1"> <img src="img/icon/hashtag.svg" alt="Icon" width="20" height="20"><span> Instagram Hashtag Downloader</span></div></a>
              </div>
          </div>
          <div class="col-md-4 col-6">
              <div class="card m-2 text-center">
                  <a href="profile"><div class="card-body m-1"> <img src="img/icon/profile.svg" alt="Icon" width="20" height="20"><span> Instagram Profile Downloader</span></div></a>
              </div>
          </div>
          <div class="col-md-4 col-6">
              <div class="card m-2 text-center">
                  <a href="private"><div class="card-body m-1"> <img src="img/icon/private.svg" alt="Icon" width="20" height="20"><span> Instagram Private Downloader</span></div></a>
              </div>
          </div>
		  <div class="col-md-4 col-6">
              <div class="card m-2 text-center">
                  <a href="stories"><div class="card-body m-1"> <img src="img/icon/stories.svg" alt="Icon" width="20" height="20"><span> Instagram Stories Downloader</span></div></a>
              </div>
          </div>
		  <div class="col-md-4 col-6">
              <div class="card m-2 text-center">
                  <a href="highlights"><div class="card-body m-1"> <img src="img/icon/highlights.svg" alt="Icon" width="20" height="20"><span> Instagram Highlights Downloader</span></div></a>
              </div>
          </div>
		  <!-- Add Addon Here -->
      </div>
      </div>
	  
	  <div class="container my-2">
	  <?php echo $adcode; ?>
	  </div>

        <div class="container text-center p-3 mt-3">
            <h3>What is Insta Pro Downloader?</h3>
            <p> <a class="iglink" href="">Insta Pro Downloader </a>is the fastest and easiest Instagram downloader. With Insta Pro Downloader you can easily download <strong>Instagram photos, videos, reels, IGTV and profile pictures</strong> for free.</p><a class="btn btn-primary" href="#howto">How To Use Insta Pro Downloader ?</a>
        </div>
      